#include <iostream>

using namespace std;

int main() 
{ 
 cout << "OI MUNDO MERDA DA PORRA!" << endl;
 system("pause");
 return 0;
}